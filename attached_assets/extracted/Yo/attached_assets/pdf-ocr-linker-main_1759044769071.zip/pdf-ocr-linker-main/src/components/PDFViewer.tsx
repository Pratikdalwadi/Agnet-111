import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, RotateCw } from 'lucide-react';

interface BoundingBox {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  text: string;
  page: number;
}

interface PDFViewerProps {
  pdfUrl?: string;
  boundingBoxes: BoundingBox[];
  selectedTextId?: string;
  onTextSelect?: (textId: string) => void;
}

export const PDFViewer: React.FC<PDFViewerProps> = ({
  pdfUrl,
  boundingBoxes,
  selectedTextId,
  onTextSelect
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages] = useState(2); // Mock total pages
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const viewerRef = useRef<HTMLDivElement>(null);
  const documentRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to selected text
  useEffect(() => {
    if (selectedTextId && documentRef.current) {
      const selectedBox = boundingBoxes.find(box => box.id === selectedTextId);
      if (selectedBox) {
        // Switch to the page containing the selected text
        if (selectedBox.page !== currentPage) {
          setCurrentPage(selectedBox.page);
        }

        // Scroll to the bounding box position
        setTimeout(() => {
          const boxElement = document.querySelector(`[data-text-id="${selectedTextId}"]`) as HTMLElement;
          if (boxElement && viewerRef.current) {
            const viewerRect = viewerRef.current.getBoundingClientRect();
            const boxRect = boxElement.getBoundingClientRect();
            
            const scrollLeft = viewerRef.current.scrollLeft + boxRect.left - viewerRect.left - viewerRect.width / 2;
            const scrollTop = viewerRef.current.scrollTop + boxRect.top - viewerRect.top - viewerRect.height / 2;
            
            viewerRef.current.scrollTo({
              left: Math.max(0, scrollLeft),
              top: Math.max(0, scrollTop),
              behavior: 'smooth'
            });
          }
        }, 100);
      }
    }
  }, [selectedTextId, currentPage, boundingBoxes]);

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 25, 200));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 25, 50));
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const currentPageBoxes = boundingBoxes.filter(box => box.page === currentPage);

  const handleBoundingBoxClick = useCallback((textId: string) => {
    if (onTextSelect) {
      onTextSelect(textId);
    }
  }, [onTextSelect]);

  return (
    <div className="flex flex-col h-full">
      {/* PDF Controls */}
      <div className="flex items-center justify-between p-3 border-b border-border bg-card">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium px-3 py-1 bg-secondary rounded">
            {currentPage} / {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium px-2">{zoom}%</span>
          <Button variant="outline" size="sm" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={handleRotate}>
            <RotateCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* PDF Viewer */}
      <div 
        ref={viewerRef}
        className="flex-1 overflow-auto bg-viewer-bg p-4"
      >
        <Card className="relative mx-auto shadow-lg">
          {/* Mock PDF Content */}
          <div 
            ref={documentRef}
            className="bg-white relative mx-auto"
            style={{
              width: `${600 * (zoom / 100)}px`,
              height: `${800 * (zoom / 100)}px`,
              transform: `rotate(${rotation}deg)`,
              transformOrigin: 'center'
            }}
          >
            {/* Sample medical report content for page 1 */}
            {currentPage === 1 && (
              <div className="p-8 text-xs leading-relaxed">
                <div className="text-center mb-6">
                  <div className="bg-highlight-teal text-white px-4 py-2 inline-block rounded mb-2">
                    DERMATOPATHOLOGY REPORT
                  </div>
                  <div className="text-sm">
                    <div>1901 C Street, Ste 2000</div>
                    <div>Sacramento CA 95816</div>
                    <div>Tel: (916) 446-8539</div>
                    <div>Fax: (916) 446-8539</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-6 text-xs">
                  <div className="border border-highlight-green p-2">
                    <div><strong>Patient:</strong> TEST, PATIENT</div>
                    <div><strong>Accn#:</strong></div>
                    <div><strong>Doctor:</strong> DPMG</div>
                    <div>3301 C St Suite 200E</div>
                    <div>Sacramento CA, 95816</div>
                  </div>
                  <div className="border border-highlight-blue p-2">
                    <div><strong>Age:</strong> 14 (04/01/00)</div>
                    <div><strong>Sex:</strong> MALE</div>
                  </div>
                  <div className="border border-highlight-purple p-2">
                    <div><strong>Pathology #:</strong> DDS-14-10962</div>
                    <div><strong>DPMG case only:</strong> 0700300</div>
                    <div><strong>Date Obtained:</strong> 04/30/2014</div>
                    <div><strong>Date Received:</strong> 05/01/2014</div>
                  </div>
                </div>

                <div className="border border-highlight-green p-3 mb-4">
                  <div><strong>CLINICAL DATA:</strong> 258.2. A: R/O WART. B: R/O LINEA</div>
                  <div><strong>SPECIMENS:</strong></div>
                  <div>A. RIGHT ARM SHAVE BIOPSY</div>
                  <div>B. LEFT NECK SHAVE BIOPSY</div>
                </div>

                <div className="border border-highlight-teal p-4">
                  <div className="font-bold mb-2">DIAGNOSIS:</div>
                  <div className="mb-2">
                    <strong>A.</strong> SKIN, RIGHT ARM, SHAVE BIOPSY:
                    COMPATIBLE WITH PERFORATING DISORDER WITH FEATURES OF
                    ELASTOSIS PERFORANS SERPIGINOSA.
                  </div>
                  <div>
                    <strong>B.</strong> SKIN, LEFT NECK, SHAVE BIOPSY:
                    <div className="ml-4">
                      <div>1. COMPATIBLE WITH PERFORATING DISORDER WITH FEATURES
                      OF ELASTOSIS PERFORANS SERPIGINOSA.</div>
                      <div>2. ASSOCIATED SPONGIOTIC DERMATITIS WITH OCCASIONAL
                      EOSINOPHILS (SEE NOTE).</div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 border border-highlight-orange p-4">
                  <div className="font-bold mb-2">NOTE:</div>
                  <div className="text-justify">
                    Elastosis perforans serpiginosa presents as small papules, either grouped or in a circular or 
                    serpiginous arrangement, often on the face, neck, upper extremities, and trunk. The disorder has a predilection 
                    for males and typically occurs in the second decade. Up to a third of cases have been reported to be associated 
                    with an associated systemic disorder or connective tissue disorder. Some cases are associated with prolonged 
                    use of penicillamine. Clinical correlation is recommended.
                  </div>
                </div>
              </div>
            )}

            {/* Sample content for page 2 */}
            {currentPage === 2 && (
              <div className="p-8 text-xs leading-relaxed">
                <div className="text-center mb-6">
                  <div className="bg-highlight-teal text-white px-4 py-2 inline-block rounded mb-2">
                    DERMATOPATHOLOGY REPORT - PAGE 2
                  </div>
                </div>

                <div className="border border-highlight-blue p-4 mb-6">
                  <div className="font-bold mb-2">MICROSCOPIC FINDINGS:</div>
                  <div className="mb-2">
                    <strong>Specimen A (Right Arm):</strong> The epidermis shows mild hyperkeratosis and focal parakeratosis. 
                    There is a well-demarcated vertical column of parakeratotic and keratotic material extending through 
                    the epidermis. The dermis shows fragmented elastic fibers within the parakeratotic column.
                  </div>
                  <div>
                    <strong>Specimen B (Left Neck):</strong> Similar findings to specimen A with additional mild spongiosis 
                    and scattered eosinophils in the superficial dermis.
                  </div>
                </div>

                <div className="border border-highlight-green p-4 mb-6">
                  <div className="font-bold mb-2">SPECIAL STAINS:</div>
                  <div>• Verhoeff-van Gieson stain: Highlights fragmented elastic fibers</div>
                  <div>• PAS stain: Negative for fungal organisms</div>
                  <div>• H&E sections reviewed</div>
                </div>

                <div className="border border-highlight-purple p-4">
                  <div className="font-bold mb-2">RECOMMENDATIONS:</div>
                  <div>1. Clinical correlation recommended</div>
                  <div>2. Consider evaluation for underlying connective tissue disorder</div>
                  <div>3. Follow-up as clinically indicated</div>
                </div>

                <div className="mt-8 text-center text-xs text-muted-foreground">
                  <div>--- END OF REPORT ---</div>
                  <div className="mt-2">Electronically signed by: Dr. Pathologist, MD</div>
                  <div>Date: 05/02/2014</div>
                </div>
              </div>
            )}

            {/* Render Bounding Boxes with precise positioning */}
            {currentPageBoxes.map((box) => (
              <div
                key={box.id}
                data-text-id={box.id}
                className={`absolute cursor-pointer transition-all duration-200 ${
                  selectedTextId === box.id 
                    ? 'border-2 border-highlight-orange bg-highlight-orange/20 shadow-lg z-20 animate-pulse' 
                    : 'border border-transparent hover:border-highlight-teal hover:bg-highlight-teal/10 z-10'
                }`}
                style={{
                  left: `${box.x * (zoom / 100)}px`,
                  top: `${box.y * (zoom / 100)}px`,
                  width: `${box.width * (zoom / 100)}px`,
                  height: `${box.height * (zoom / 100)}px`,
                  borderColor: selectedTextId === box.id 
                    ? 'hsl(var(--highlight-orange))' 
                    : selectedTextId ? 'transparent' : 'hsl(var(--highlight-teal) / 0.3)',
                  borderWidth: selectedTextId === box.id ? '2px' : '1px',
                  borderRadius: '2px'
                }}
                onClick={() => handleBoundingBoxClick(box.id)}
                title={`Click to highlight: ${box.text.substring(0, 100)}...`}
              />
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};