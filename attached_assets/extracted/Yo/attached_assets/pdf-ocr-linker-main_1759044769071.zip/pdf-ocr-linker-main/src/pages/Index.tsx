import React, { useState } from 'react';
import { PDFViewer } from '@/components/PDFViewer';
import { TextExtractionPanel } from '@/components/TextExtractionPanel';
import { FileUpload } from '@/components/FileUpload';
import { Button } from '@/components/ui/button';
import { FileText, Settings, HelpCircle } from 'lucide-react';

// Precise mock data with exact text positioning like professional OCR
const mockExtractedTexts = [
  {
    id: 'text-1',
    type: 'header' as const,
    content: 'DERMATOPATHOLOGY REPORT',
    confidence: 0.97,
    coordinates: { x: 165, y: 40, width: 270, height: 20, page: 1 }
  },
  {
    id: 'text-2',
    type: 'text' as const,
    content: '1901 C Street, Ste 2000',
    confidence: 0.94,
    coordinates: { x: 220, y: 85, width: 160, height: 12, page: 1 }
  },
  {
    id: 'text-3',
    type: 'text' as const,
    content: 'Sacramento CA 95816',
    confidence: 0.94,
    coordinates: { x: 230, y: 100, width: 140, height: 12, page: 1 }
  },
  {
    id: 'text-4',
    type: 'text' as const,
    content: 'Tel: (916) 446-8539',
    confidence: 0.94,
    coordinates: { x: 240, y: 115, width: 120, height: 12, page: 1 }
  },
  {
    id: 'text-5',
    type: 'text' as const,
    content: 'Fax: (916) 446-8539',
    confidence: 0.94,
    coordinates: { x: 240, y: 130, width: 120, height: 12, page: 1 }
  },
  {
    id: 'text-6',
    type: 'text' as const,
    content: 'Patient: TEST, PATIENT',
    confidence: 0.92,
    coordinates: { x: 32, y: 174, width: 140, height: 12, page: 1 }
  },
  {
    id: 'text-7',
    type: 'text' as const,
    content: 'Accn#:',
    confidence: 0.92,
    coordinates: { x: 32, y: 188, width: 45, height: 12, page: 1 }
  },
  {
    id: 'text-8',
    type: 'text' as const,
    content: 'Doctor: DPMG',
    confidence: 0.92,
    coordinates: { x: 32, y: 202, width: 85, height: 12, page: 1 }
  },
  {
    id: 'text-9',
    type: 'text' as const,
    content: '3301 C St Suite 200E',
    confidence: 0.92,
    coordinates: { x: 32, y: 216, width: 130, height: 12, page: 1 }
  },
  {
    id: 'text-10',
    type: 'text' as const,
    content: 'Sacramento CA, 95816',
    confidence: 0.92,
    coordinates: { x: 32, y: 230, width: 125, height: 12, page: 1 }
  },
  {
    id: 'text-11',
    type: 'text' as const,
    content: 'Age: 14 (04/01/00)',
    confidence: 0.90,
    coordinates: { x: 192, y: 174, width: 100, height: 12, page: 1 }
  },
  {
    id: 'text-12',
    type: 'text' as const,
    content: 'Sex: MALE',
    confidence: 0.90,
    coordinates: { x: 192, y: 188, width: 65, height: 12, page: 1 }
  },
  {
    id: 'text-13',
    type: 'text' as const,
    content: 'Pathology #: DDS-14-10962',
    confidence: 0.95,
    coordinates: { x: 312, y: 174, width: 160, height: 12, page: 1 }
  },
  {
    id: 'text-14',
    type: 'text' as const,
    content: 'DPMG case only: 0700300',
    confidence: 0.95,
    coordinates: { x: 312, y: 188, width: 145, height: 12, page: 1 }
  },
  {
    id: 'text-15',
    type: 'text' as const,
    content: 'Date Obtained: 04/30/2014',
    confidence: 0.95,
    coordinates: { x: 312, y: 202, width: 140, height: 12, page: 1 }
  },
  {
    id: 'text-16',
    type: 'text' as const,
    content: 'Date Received: 05/01/2014',
    confidence: 0.95,
    coordinates: { x: 312, y: 216, width: 135, height: 12, page: 1 }
  },
  {
    id: 'text-17',
    type: 'text' as const,
    content: 'CLINICAL DATA: 258.2. A: R/O WART. B: R/O LINEA',
    confidence: 0.91,
    coordinates: { x: 32, y: 258, width: 380, height: 12, page: 1 }
  },
  {
    id: 'text-18',
    type: 'text' as const,
    content: 'SPECIMENS:',
    confidence: 0.93,
    coordinates: { x: 32, y: 280, width: 85, height: 12, page: 1 }
  },
  {
    id: 'text-19',
    type: 'text' as const,
    content: 'A. RIGHT ARM SHAVE BIOPSY',
    confidence: 0.93,
    coordinates: { x: 32, y: 294, width: 180, height: 12, page: 1 }
  },
  {
    id: 'text-20',
    type: 'text' as const,
    content: 'B. LEFT NECK SHAVE BIOPSY',
    confidence: 0.93,
    coordinates: { x: 32, y: 308, width: 175, height: 12, page: 1 }
  },
  {
    id: 'text-21',
    type: 'header' as const,
    content: 'DIAGNOSIS:',
    confidence: 0.98,
    coordinates: { x: 32, y: 340, width: 85, height: 14, page: 1 }
  },
  {
    id: 'text-22',
    type: 'text' as const,
    content: 'A. SKIN, RIGHT ARM, SHAVE BIOPSY: COMPATIBLE WITH PERFORATING DISORDER WITH FEATURES OF ELASTOSIS PERFORANS SERPIGINOSA.',
    confidence: 0.89,
    coordinates: { x: 32, y: 362, width: 520, height: 26, page: 1 }
  },
  {
    id: 'text-23',
    type: 'text' as const,
    content: 'B. SKIN, LEFT NECK, SHAVE BIOPSY:',
    confidence: 0.87,
    coordinates: { x: 32, y: 398, width: 230, height: 12, page: 1 }
  },
  {
    id: 'text-24',
    type: 'text' as const,
    content: '1. COMPATIBLE WITH PERFORATING DISORDER WITH FEATURES OF ELASTOSIS PERFORANS SERPIGINOSA.',
    confidence: 0.87,
    coordinates: { x: 56, y: 416, width: 485, height: 12, page: 1 }
  },
  {
    id: 'text-25',
    type: 'text' as const,
    content: '2. ASSOCIATED SPONGIOTIC DERMATITIS WITH OCCASIONAL EOSINOPHILS (SEE NOTE).',
    confidence: 0.87,
    coordinates: { x: 56, y: 434, width: 420, height: 12, page: 1 }
  },
  {
    id: 'text-26',
    type: 'header' as const,
    content: 'NOTE:',
    confidence: 0.96,
    coordinates: { x: 32, y: 470, width: 45, height: 14, page: 1 }
  },
  {
    id: 'text-27',
    type: 'text' as const,
    content: 'Elastosis perforans serpiginosa presents as small papules, either grouped or in a circular or serpiginous arrangement, often on the face, neck, upper extremities, and trunk. The disorder has a predilection for males and typically occurs in the second decade. Up to a third of cases have been reported to be associated with an associated systemic disorder or connective tissue disorder. Some cases are associated with prolonged use of penicillamine. Clinical correlation is recommended.',
    confidence: 0.88,
    coordinates: { x: 32, y: 492, width: 520, height: 78, page: 1 }
  },
  // Page 2 content with precise coordinates
  {
    id: 'text-28',
    type: 'header' as const,
    content: 'DERMATOPATHOLOGY REPORT - PAGE 2',
    confidence: 0.96,
    coordinates: { x: 135, y: 40, width: 330, height: 20, page: 2 }
  },
  {
    id: 'text-29',
    type: 'header' as const,
    content: 'MICROSCOPIC FINDINGS:',
    confidence: 0.95,
    coordinates: { x: 32, y: 100, width: 175, height: 14, page: 2 }
  },
  {
    id: 'text-30',
    type: 'text' as const,
    content: 'Specimen A (Right Arm): The epidermis shows mild hyperkeratosis and focal parakeratosis. There is a well-demarcated vertical column of parakeratotic and keratotic material extending through the epidermis. The dermis shows fragmented elastic fibers within the parakeratotic column.',
    confidence: 0.90,
    coordinates: { x: 32, y: 122, width: 520, height: 52, page: 2 }
  },
  {
    id: 'text-31',
    type: 'text' as const,
    content: 'Specimen B (Left Neck): Similar findings to specimen A with additional mild spongiosis and scattered eosinophils in the superficial dermis.',
    confidence: 0.91,
    coordinates: { x: 32, y: 184, width: 520, height: 26, page: 2 }
  },
  {
    id: 'text-32',
    type: 'header' as const,
    content: 'SPECIAL STAINS:',
    confidence: 0.97,
    coordinates: { x: 32, y: 230, width: 125, height: 14, page: 2 }
  },
  {
    id: 'text-33',
    type: 'text' as const,
    content: '• Verhoeff-van Gieson stain: Highlights fragmented elastic fibers',
    confidence: 0.92,
    coordinates: { x: 32, y: 252, width: 350, height: 12, page: 2 }
  },
  {
    id: 'text-34',
    type: 'text' as const,
    content: '• PAS stain: Negative for fungal organisms',
    confidence: 0.92,
    coordinates: { x: 32, y: 266, width: 250, height: 12, page: 2 }
  },
  {
    id: 'text-35',
    type: 'text' as const,
    content: '• H&E sections reviewed',
    confidence: 0.92,
    coordinates: { x: 32, y: 280, width: 150, height: 12, page: 2 }
  },
  {
    id: 'text-36',
    type: 'header' as const,
    content: 'RECOMMENDATIONS:',
    confidence: 0.96,
    coordinates: { x: 32, y: 320, width: 155, height: 14, page: 2 }
  },
  {
    id: 'text-37',
    type: 'text' as const,
    content: '1. Clinical correlation recommended',
    confidence: 0.93,
    coordinates: { x: 32, y: 342, width: 210, height: 12, page: 2 }
  },
  {
    id: 'text-38',
    type: 'text' as const,
    content: '2. Consider evaluation for underlying connective tissue disorder',
    confidence: 0.93,
    coordinates: { x: 32, y: 356, width: 385, height: 12, page: 2 }
  },
  {
    id: 'text-39',
    type: 'text' as const,
    content: '3. Follow-up as clinically indicated',
    confidence: 0.93,
    coordinates: { x: 32, y: 370, width: 230, height: 12, page: 2 }
  },
  {
    id: 'text-40',
    type: 'text' as const,
    content: '--- END OF REPORT ---',
    confidence: 0.94,
    coordinates: { x: 230, y: 450, width: 140, height: 12, page: 2 }
  },
  {
    id: 'text-41',
    type: 'text' as const,
    content: 'Electronically signed by: Dr. Pathologist, MD',
    confidence: 0.94,
    coordinates: { x: 190, y: 472, width: 220, height: 12, page: 2 }
  },
  {
    id: 'text-42',
    type: 'text' as const,
    content: 'Date: 05/02/2014',
    confidence: 0.94,
    coordinates: { x: 260, y: 486, width: 80, height: 12, page: 2 }
  }
];

const mockBoundingBoxes = mockExtractedTexts.map(text => ({
  id: text.id,
  x: text.coordinates.x,
  y: text.coordinates.y,
  width: text.coordinates.width,
  height: text.coordinates.height,
  page: text.coordinates.page,
  color: text.type === 'header' ? 'hsl(var(--highlight-teal))' : 'hsl(var(--highlight-green))',
  text: text.content
}));

const Index = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedTextId, setSelectedTextId] = useState<string | undefined>();
  const [extractedTexts, setExtractedTexts] = useState(mockExtractedTexts);
  const [boundingBoxes, setBoundingBoxes] = useState(mockBoundingBoxes);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleFileProcess = async (file: File) => {
    setIsProcessing(true);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // In a real implementation, you would:
    // 1. Upload the PDF to your OCR service
    // 2. Process the document with OCR
    // 3. Extract text and coordinates
    // 4. Update the state with real data
    
    setExtractedTexts(mockExtractedTexts);
    setBoundingBoxes(mockBoundingBoxes);
    setIsProcessing(false);
  };

  const handleTextSelect = (textId: string) => {
    setSelectedTextId(selectedTextId === textId ? undefined : textId);
  };

  if (!selectedFile) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <FileText className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">OCR Extraction Studio</h1>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <HelpCircle className="h-4 w-4 mr-2" />
                Help
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Upload Section */}
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="w-full max-w-lg">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Extract Text from PDF Documents</h2>
              <p className="text-muted-foreground">
                Upload your PDF and get precise text extraction with interactive highlighting
              </p>
            </div>
            
            <FileUpload
              onFileSelect={handleFileSelect}
              onFileProcess={handleFileProcess}
              isProcessing={isProcessing}
            />
            
            <div className="mt-6 text-center text-sm text-muted-foreground">
              <p>Features:</p>
              <ul className="mt-2 space-y-1">
                <li>• Advanced OCR text extraction</li>
                <li>• Interactive coordinate mapping</li>
                <li>• Multiple export formats (Markdown, JSON)</li>
                <li>• Precise bounding box highlighting</li>
              </ul>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <FileText className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">OCR Extraction Studio</h1>
            </div>
            {selectedFile && (
              <div className="text-sm text-muted-foreground">
                • {selectedFile.name}
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setSelectedFile(null);
                setSelectedTextId(undefined);
              }}
            >
              New Document
            </Button>
            <Button variant="ghost" size="sm">
              <HelpCircle className="h-4 w-4 mr-2" />
              Help
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* PDF Viewer */}
        <div className="w-1/2 border-r border-border">
          <PDFViewer
            pdfUrl={selectedFile ? URL.createObjectURL(selectedFile) : undefined}
            boundingBoxes={boundingBoxes}
            selectedTextId={selectedTextId}
            onTextSelect={handleTextSelect}
          />
        </div>

        {/* Text Extraction Panel */}
        <div className="w-1/2">
          <TextExtractionPanel
            extractedTexts={extractedTexts}
            selectedTextId={selectedTextId}
            onTextSelect={handleTextSelect}
          />
        </div>
      </div>
    </div>
  );
};

export default Index;