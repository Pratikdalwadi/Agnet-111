import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Download, Copy, FileText, Code } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ExtractedText {
  id: string;
  type: 'header' | 'text' | 'table' | 'figure';
  content: string;
  confidence: number;
  coordinates: {
    x: number;
    y: number;
    width: number;
    height: number;
    page: number;
  };
}

interface TextExtractionPanelProps {
  extractedTexts: ExtractedText[];
  selectedTextId?: string;
  onTextSelect?: (textId: string) => void;
}

export const TextExtractionPanel: React.FC<TextExtractionPanelProps> = ({
  extractedTexts,
  selectedTextId,
  onTextSelect
}) => {
  const [activeTab, setActiveTab] = useState('extract');
  const { toast } = useToast();

  const handleTextClick = (textId: string) => {
    if (onTextSelect) {
      onTextSelect(textId);
    }
  };

  const handleCopy = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      toast({
        title: "Copied to clipboard",
        description: "Text has been copied successfully",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy text to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleExportMarkdown = () => {
    const markdown = extractedTexts.map(item => {
      switch (item.type) {
        case 'header':
          return `## ${item.content}\n`;
        case 'text':
          return `${item.content}\n`;
        case 'table':
          return `\n${item.content}\n`;
        case 'figure':
          return `![Figure](figure) ${item.content}\n`;
        default:
          return item.content;
      }
    }).join('\n');

    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'extracted-text.md';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = () => {
    const jsonData = {
      extractedAt: new Date().toISOString(),
      totalItems: extractedTexts.length,
      data: extractedTexts
    };

    const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'extracted-data.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'header': return 'bg-highlight-blue text-white';
      case 'text': return 'bg-highlight-green text-white';
      case 'table': return 'bg-highlight-purple text-white';
      case 'figure': return 'bg-highlight-orange text-white';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="flex flex-col h-full bg-text-panel-bg">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <TabsList className="grid w-60 grid-cols-3">
            <TabsTrigger value="parse" className="text-sm">Parse</TabsTrigger>
            <TabsTrigger value="extract" className="text-sm">Extract</TabsTrigger>
            <TabsTrigger value="chat" className="text-sm">Chat</TabsTrigger>
          </TabsList>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportMarkdown}>
              <FileText className="h-4 w-4 mr-1" />
              Markdown
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportJSON}>
              <Code className="h-4 w-4 mr-1" />
              JSON
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="parse" className="flex-1 overflow-hidden">
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-4">Document Structure</h3>
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">
                Document parsing will be available soon...
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="extract" className="flex-1 overflow-auto">
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Extracted Content</h3>
              <Badge variant="secondary">{extractedTexts.length} items</Badge>
            </div>

            <div className="space-y-3">
              {extractedTexts.map((item, index) => (
                <Card 
                  key={item.id}
                  className={`p-4 cursor-pointer transition-all duration-200 hover:shadow-md ${
                    selectedTextId === item.id 
                      ? 'ring-2 ring-primary bg-accent/50' 
                      : 'hover:bg-accent/20'
                  }`}
                  onClick={() => handleTextClick(item.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge 
                        className={`text-xs ${getTypeColor(item.type)}`}
                      >
                        {item.type}
                      </Badge>
                      <span className="text-sm font-medium text-primary">
                        {index + 1}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {Math.round(item.confidence * 100)}%
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(item.content);
                        }}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="text-sm text-foreground whitespace-pre-wrap">
                    {item.content}
                  </div>
                  
                  <div className="mt-2 text-xs text-muted-foreground">
                    Page {item.coordinates.page} • 
                    Position: ({item.coordinates.x}, {item.coordinates.y})
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="chat" className="flex-1 overflow-hidden">
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-4">Document Chat</h3>
            <div className="text-sm text-muted-foreground">
              Chat with your document will be available soon...
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};