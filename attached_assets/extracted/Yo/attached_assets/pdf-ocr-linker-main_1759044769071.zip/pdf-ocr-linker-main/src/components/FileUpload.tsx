import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, X, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onFileProcess: (file: File) => Promise<void>;
  isProcessing?: boolean;
  accept?: string;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFileSelect,
  onFileProcess,
  isProcessing = false,
  accept = '.pdf'
}) => {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        title: "Invalid file type",
        description: "Please upload a PDF file only",
        variant: "destructive",
      });
      return;
    }

    setUploadedFile(file);
    setProcessingStatus('processing');
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      onFileSelect(file);
      await onFileProcess(file);
      setUploadProgress(100);
      setProcessingStatus('success');
      
      toast({
        title: "File processed successfully",
        description: "OCR extraction completed",
      });
    } catch (error) {
      setProcessingStatus('error');
      toast({
        title: "Processing failed",
        description: "Failed to process the PDF file",
        variant: "destructive",
      });
    }
  }, [onFileSelect, onFileProcess, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    maxFiles: 1,
    disabled: isProcessing
  });

  const handleRemoveFile = () => {
    setUploadedFile(null);
    setUploadProgress(0);
    setProcessingStatus('idle');
  };

  const getStatusIcon = () => {
    switch (processingStatus) {
      case 'processing':
        return <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-success" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-destructive" />;
      default:
        return <FileText className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusText = () => {
    switch (processingStatus) {
      case 'processing':
        return 'Processing document...';
      case 'success':
        return 'Processing complete';
      case 'error':
        return 'Processing failed';
      default:
        return 'Ready to upload';
    }
  };

  if (uploadedFile) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {getStatusIcon()}
            <div>
              <p className="font-medium">{uploadedFile.name}</p>
              <p className="text-sm text-muted-foreground">
                {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB • {getStatusText()}
              </p>
            </div>
          </div>
          
          {processingStatus !== 'processing' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRemoveFile}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {processingStatus === 'processing' && (
          <div className="space-y-2">
            <Progress value={uploadProgress} className="h-2" />
            <p className="text-xs text-muted-foreground text-center">
              Extracting text from PDF... {uploadProgress}%
            </p>
          </div>
        )}

        {processingStatus === 'success' && (
          <div className="text-sm text-success text-center">
            ✓ Text extraction completed successfully
          </div>
        )}

        {processingStatus === 'error' && (
          <div className="flex items-center justify-center gap-2">
            <p className="text-sm text-destructive">Processing failed</p>
            <Button variant="outline" size="sm" onClick={handleRemoveFile}>
              Try again
            </Button>
          </div>
        )}
      </Card>
    );
  }

  return (
    <Card 
      {...getRootProps()} 
      className={`p-8 border-2 border-dashed cursor-pointer transition-all duration-200 ${
        isDragActive 
          ? 'border-primary bg-accent/50' 
          : 'border-border hover:border-primary/50 hover:bg-accent/20'
      }`}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center text-center space-y-4">
        <div className={`p-4 rounded-full ${isDragActive ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
          <Upload className="h-8 w-8" />
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-2">
            {isDragActive ? 'Drop your PDF here' : 'Upload PDF Document'}
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Drag and drop your PDF file here, or click to select
          </p>
          <Button variant="outline" className="mt-2">
            Choose File
          </Button>
        </div>
        
        <div className="text-xs text-muted-foreground">
          Supports PDF files up to 20MB
        </div>
      </div>
    </Card>
  );
};